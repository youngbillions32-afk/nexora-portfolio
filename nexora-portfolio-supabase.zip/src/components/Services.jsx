const services = [
  ['01', 'Landing Pages', 'High-converting pages for products, services, and campaigns.'],
  ['02', 'Business Websites', 'Professional websites that make your business look credible online.'],
  ['03', 'Portfolio Websites', 'Clean personal portfolios for creatives, freelancers, and professionals.'],
  ['04', 'Website Redesign', 'Give an outdated website a fresh, modern, mobile-friendly look.'],
]

export default function Services() {
  return (
    <section id="services" className="section">
      <div className="container">
        <p className="eyebrow">WHAT I DO</p>
        <div className="section-head">
          <h2>Simple. Sharp. <span>Effective.</span></h2>
          <p>Everything you need to build a stronger presence online.</p>
        </div>

        <div className="services-grid">
          {services.map(([num, title, text]) => (
            <article className="service" key={num}>
              <span className="service-num">{num}</span>
              <h3>{title}</h3>
              <p>{text}</p>
              <span className="arrow">↗</span>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}