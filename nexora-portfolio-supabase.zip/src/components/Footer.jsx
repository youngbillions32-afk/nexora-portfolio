export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div>
          <a className="logo" href="#home">NEXORA<span>.</span></a>
          <p>Web design & development.</p>
        </div>
        <p>© {new Date().getFullYear()} Nexora Web Studio.</p>
      </div>
    </footer>
  )
}