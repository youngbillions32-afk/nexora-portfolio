import { useState } from 'react'

export default function Navbar() {
  const [open, setOpen] = useState(false)

  const links = [
    ['Home', '#home'],
    ['Services', '#services'],
    ['Projects', '#projects'],
    ['Contact', '#contact'],
  ]

  return (
    <header className="nav-wrap">
      <nav className="nav container">
        <a className="logo" href="#home">NEXORA<span>.</span></a>

        <button
          className="menu-btn"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          ☰
        </button>

        <div className={`nav-links ${open ? 'show' : ''}`}>
          {links.map(([label, href]) => (
            <a key={href} href={href} onClick={() => setOpen(false)}>
              {label}
            </a>
          ))}
          <a className="nav-cta" href="#contact" onClick={() => setOpen(false)}>
            Let's talk
          </a>
        </div>
      </nav>
    </header>
  )
}