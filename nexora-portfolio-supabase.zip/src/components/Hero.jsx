export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="container hero-grid">
        <div>
          <p className="eyebrow">WEB DESIGN • DEVELOPMENT • BRANDING</p>
          <h1>Websites that make your brand <span>stand out.</span></h1>
          <p className="hero-copy">
            I design and build fast, modern websites that help businesses,
            creators, and personal brands look professional online.
          </p>

          <div className="hero-actions">
            <a className="btn primary" href="#projects">View my work</a>
            <a className="btn secondary" href="#contact">Start a project →</a>
          </div>

          <div className="mini-stats">
            <div><strong>Modern</strong><span>Design</span></div>
            <div><strong>Fast</strong><span>Websites</span></div>
            <div><strong>Mobile</strong><span>First</span></div>
          </div>
        </div>

        <div className="hero-card">
          <div className="card-glow"></div>
          <p className="card-label">NEXORA / WEB STUDIO</p>
          <div className="browser">
            <div className="browser-top"><i></i><i></i><i></i></div>
            <div className="browser-content">
              <small>YOUR BRAND</small>
              <h3>Build something<br /><em>people remember.</em></h3>
              <div className="fake-line"></div>
              <div className="fake-line short"></div>
              <div className="fake-button">EXPLORE</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}