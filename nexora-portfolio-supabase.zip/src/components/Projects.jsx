const projects = [
  { name: 'Marketly', type: 'E-commerce concept', tag: 'MARKETPLACE' },
  { name: 'Nexora Studio', type: 'Creative portfolio', tag: 'PORTFOLIO' },
  { name: 'Project Three', type: 'Business website', tag: 'BUSINESS' },
]

export default function Projects() {
  return (
    <section id="projects" className="section projects-section">
      <div className="container">
        <p className="eyebrow">SELECTED WORK</p>
        <div className="section-head">
          <h2>Projects I've <span>built.</span></h2>
          <p>A few examples of the kind of digital experiences I create.</p>
        </div>

        <div className="projects-grid">
          {projects.map((project, index) => (
            <article className={`project project-${index + 1}`} key={project.name}>
              <div className="project-visual">
                <span>{project.tag}</span>
                <div className="project-window">
                  <b>{project.name}</b>
                  <div className="project-bars"></div>
                </div>
              </div>
              <div className="project-info">
                <div>
                  <h3>{project.name}</h3>
                  <p>{project.type}</p>
                </div>
                <span className="round-arrow">↗</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}