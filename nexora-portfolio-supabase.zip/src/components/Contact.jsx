import { useState } from 'react'
import { supabase } from '../lib/supabase'

export default function Contact() {
  const whatsapp = '23490281505243'
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [status, setStatus] = useState('')
  const [loading, setLoading] = useState(false)

  function updateField(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setStatus('')

    if (!form.name.trim() || !form.message.trim()) {
      setStatus('Please enter your name and message.')
      return
    }

    setLoading(true)

    const { error } = await supabase.from('client_leads').insert({
      name: form.name.trim(),
      email: form.email.trim() || null,
      message: form.message.trim(),
    })

    setLoading(false)

    if (error) {
      console.error(error)
      setStatus('Something went wrong. Please try WhatsApp instead.')
      return
    }

    setForm({ name: '', email: '', message: '' })
    setStatus("Message sent! I'll get back to you soon.")
  }

  return (
    <section id="contact" className="contact section">
      <div className="container contact-box">
        <div>
          <p className="eyebrow">HAVE A PROJECT?</p>
          <h2>Let's build something <span>great.</span></h2>
          <p>Tell me what you have in mind and let's turn the idea into a website.</p>

          <form className="lead-form" onSubmit={handleSubmit}>
            <input
              name="name"
              value={form.name}
              onChange={updateField}
              placeholder="Your name"
              maxLength="100"
              required
            />
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={updateField}
              placeholder="Your email (optional)"
              maxLength="320"
            />
            <textarea
              name="message"
              value={form.message}
              onChange={updateField}
              placeholder="Tell me about your project..."
              maxLength="5000"
              rows="5"
              required
            />
            <button className="btn primary big" type="submit" disabled={loading}>
              {loading ? 'Sending...' : 'Send project enquiry →'}
            </button>
            {status && <p className="form-status" role="status">{status}</p>}
          </form>
        </div>

        <div className="contact-actions">
          <a
            className="btn secondary big"
            href={`https://wa.me/${whatsapp}`}
            target="_blank"
            rel="noreferrer"
          >
            Chat on WhatsApp ↗
          </a>
          <a className="email-link" href="mailto:hello@nexorawebstudio.com">
            hello@nexorawebstudio.com
          </a>
        </div>
      </div>
    </section>
  )
}
